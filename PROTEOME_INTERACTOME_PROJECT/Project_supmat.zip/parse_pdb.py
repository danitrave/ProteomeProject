#!/usr/bin/python

import sys
import numpy as np

"""This function has the role to calculate the distance between two atoms. As input, 
   it takes two monomers that can be two monomers or one monomer and an heteroatom.
   Then per each pair of atoms between the two monomers or monomers and heteroatoms,
   it calculates the distance. When the distance is less the 3.5 A°, the residues 
   and the atoms involved are collected in a list called interact. At the end, this
   list will be a list of tuples or 4 elements per each monomer-monomer and 
   monomer-heteroatom interaction"""
   
def calculate_dist(at,hem):
	interact = []        #list that will contain the pairwise interactions
	for res1 in hem:              #iterate over the residues of monomer 1
		for atom1 in hem[res1]:      #iterare over the amtoms of the current residue from monomer 1 
			at1 = hem[res1][atom1]       
			for res2 in at:             #iterate over the residues of monomer 2
				for atom2 in at[res2]:       #iterate over the atoms of the current residue from monomer 2
					at2 = at[res2][atom2]
					d = np.sqrt((at1[0]-at2[0])**2+(at1[1]-at2[1])**2+(at1[2]-at2[2])**2)     #calculate distance
					if d < 3.5 and d>0:                           #check distance value
						result = (res1,res2,atom1,atom2)
						if result not in interact:            #add residues and the atoms if the check is passed
							interact += [result,]
							
	return interact

"""This function has the role of differentiate the atoms and the residues that we obtained using the other 
   functions in the scriptr assigning the correct name"""
   
def divide_residues(distance,names):   #names is a dictionary contianing {residue number:resdie name}
	distinct = list()
	for x in distance:
		distinct += [(names[x[0]]+str(x[0]),names[x[1]]+str(x[1]),x[2],x[3]),]

	return distinct
	
"""the following two tables has been designed to print the tables of the results n a user friendly way"""

def print_table_het(results):
	
	for chain in results:
		for i in results[chain]:
			print chain,'\t',i[1],'\t',i[0],'\t',i[3]+'-'+i[2]
			
def print_table_res(results):
	
	for chains in results:
		for i in results[chains]:
			print chains[0],'\t',i[0],'\t',chains[1],'\t',i[1],'\t',i[2]+'-'+i[3]

"""this function has the role to collect all the pair wise distances between each pair of monomer 
   and the monomer-heteroatoms pairs. The results are collected in a dictionary
   where the keys are the chains. This function calls, in its body, the function responsible for the 
   pairwise calculation, the function that assigns the correct names and the one that prints the table output """
				
def pair_distance(atoms,heme,names):  #the three inputs re three dictionaries
	
	final_dict = {}
	
	for chain in heme:
		dict_at = atoms[chain]      #monomer atoms
		dict_hem = heme[chain]            #heme atoms
		distance = calculate_dist(dict_at,dict_hem)   #distance calculation
		result = divide_residues(distance,names)       #residue name assigments
		final_dict[chain]=result
	
	output = print_table_het(final_dict)     #final result
	
"""this function has the role to collect all the pair wise distances between all possible 
   monomer-monomer pairs. The results are collected in a dictionary where the keys are the chains.
   This function calls, in its body, the function responsible for the pairwise calculation, 
   the function that assigns the correct names and the one that prints the table output """
	
def monomer_pair_dist(atoms,names):
	final_dict = {}
	k = len(atoms)
	keys = atoms.keys()
	for i in range(0,k):
		for j in range(i+1,k):
			mono1 = atoms[keys[i]]
			mono2 = atoms[keys[j]]
			distance = calculate_dist(mono1,mono2)
			results = divide_residues(distance,names)
			final_dict[str(keys[i])+str(keys[j])]=results
      
	output=print_table_res(final_dict)

"""This function takes as input the pdb file and it retrives the coordinates of all
   atoms of all aminoactids and heterotaoms of all chains present in pdb file. The
   results are collected in a dataframe made of three different dictionaries nested
   one within the other."""
   	
def parse_pdb(pdbfile):
	fpdb = open(pdbfile)      #opern the pdb file
	dict_atoms = dict()       #the final output will be {chain:{n:{atom:coord}}}
	dict_hem = dict()         #the final output will be {chain:{n:{atom:coord}}}
	res_name = {}                  #dictionary containig the {residue number:name}
	for line in fpdb:
		if line[0:4]=='ATOM':       #select only the atoms
			x = float(line[30:38])
			y = float(line[38:46])    #take the coordinates
			z = float(line[46:54])
			at = line[12:16].strip()      #atom type
			res = line[17:20]               #residue name
			n = line[22:26].strip()             #residue number
			res_name[n]=str(res)              
			coord = [x,y,z]
			chain = line[21]                 #chain
			if chain not in dict_atoms:              #add data in the dictionat if not already present
				dict_atoms[chain] = {}
			else:
				if n not in dict_atoms[chain]:
					dict_atoms[chain][n] = {at:coord}
				else:
					dict_atoms[chain][n][at]=coord
	
		if line[0:6]=='HETATM':           #consider the heteroatom
			res = line[17:20]
			if res != 'HOH':              #consider only HEME and OXY groups
				x = float(line[30:38])     #take coordinates
				y = float(line[38:46])
				z = float(line[46:54])
				at = line[12:16].strip()    #atom type
				n = line[22:26].strip()      #residue number
				coord = [x,y,z]
				chain = line[21]            #chain
				res_name[n]=res
				if chain not in dict_hem:    #add data in the dictionar if not already present 
					dict_hem[chain]={}
				else:
					if n not in dict_hem[chain]:
						dict_hem[chain][n] = {at:coord}
					else:
						dict_hem[chain][n][at] = coord
	
	return dict_atoms,dict_hem,res_name
	
"""function calls"""
					 
if __name__=="__main__":
	if len(sys.argv)==2:
		pdbfile = sys.argv[1]
		dict_pdb = parse_pdb(pdbfile)
		names = dict_pdb[2]
		#print pair_distance(dict_pdb[0],dict_pdb[1],names)   #heteroatoms 
		#print monomer_pair_dist(dict_pdb[0],names)           #monomers
 
