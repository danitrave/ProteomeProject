#!/usr/bin/python

import sys
import networkx as nx

"""This function has the role of parsing the Intact file. Its goal is to retrieve the 
   entire set of pairwise interaction of the human proteme. In fact, each pairwise 
   iteraction are put in list as a tuple containg (interactor1, interactor 2, taxid1,taxide2)"""
   
def parse_mitab(mitabfile):
	list_int = []
	f = open(mitabfile)      #open the Intact file
	for line in f:
		v = line.split('\t')     #generate a list of strings splitting each line by tab
		if (v[0].find('uniprotkb:')==0 and v[1].find('uniprotkb:')==0):   #consider  only pairwise interaction between proteins
			 int1 = v[0].replace('uniprotkb:','')
			 int2 = v[1].replace('uniprotkb:','')   #replace unuseful elements with empty spaces 
			 tax1=v[9].replace('taxid:','')
			 tax2=v[10].replace('taxid:','')

			 pint=(int1,int2,tax1,tax2)    #add interactor1, interaxtor2, taxid1 and taxid2 to a tuple
			 list_int.append(pint)
	
	return list_int

"""This function has the role of filter the pairwise interactions that we found by human. At the end
   we will obtain the human pairwise interactions"""
   
def filter_organism(list_int,organism):    #this function require the organism for which you are filtering out the pairwise interactions
	filter_list=[]
	organism = organism.lower()
	for pint in list_int:
		if pint[2].lower().find(organism)>-1 and pint[3].lower().find(organism)>-1:   #add the interaction only when they are found in the designed organism
			filter_list.append(pint)
	return filter_list 

"""This function has the role of eliminate redundant interaction that from the pairwise interraction list
   To do that, it simply counts the numebr of times an interactio is reported in the pairwise interaction list
   The pairwise interactions will become the keys of a dictionary and the values of each key is the number of +
   pairwise interaction found"""	

def get_unique(pp_int_list):
	dint = {}
	for pint in pp_int_list:
		k = [pint[0],pint[1]]
		k.sort()
		dint[tuple(k)]=dint.get(tuple(k),0)+1    #add 1 if the interaction has been already found 
		
	return dint

"""This fucntion has the role of calculating the statitics of the networks per each protein in the 
   protein protein interaction sub network"""
   
def statistics(graph):
	degree = graph.degree()    #calculate degree
	cluster = nx.clustering(graph)     #calculate clustring coefficient
	bc = nx.betweenness_centrality(graph)    #calculate betweenness centrality
	return degree,cluster,bc
	
"""This function has the role of creating the protein protein interaction network of the human
   proteome. Then, considering subunit alpha and subunit beta, this fucntion creates a subnetwork
   of protein protein interactions considering the interactions between a proteina and the subunit
   alpha or the subunit beta having a maximum shortst path legth of 2. Per esch node of the subnetwork
   the function calculate the degree, the clustering coefficient and the betweenness centrality"""
   
def network(nodes):
	g = nx.Graph()            #bulit the protein-protein human interaction graph
	g.add_edges_from(nodes)
	subalpha = nx.single_source_shortest_path_length(g,'P69905',cutoff=2)  #dict of nodes that have a distance with respect of my source of 2 or less
	path_1_alpha = []
	for e in subalpha:         #collect all nodes having a direct interaction with subunit alpha
		if subalpha[e]==1:
			path_1_alpha.append(e)
			
	nodes_alpha = set(list(subalpha.keys()))
	path_1_alpha = set(path_1_alpha)

	subbeta = nx.single_source_shortest_path_length(g,'P68871',cutoff=2)
	path_1_beta= []
	for i in subbeta:        #collect all nodes having a direct intraction with subunit beta
		if subbeta[i]==1:
			path_1_beta.append(i)
	nodes_beta = set(list(subbeta.keys()))
	path_1_beta = set(path_1_beta)
	
	final_set = nodes_alpha.union(nodes_beta)      #eliminate redundant interactors 
	
	final_set_path1 = path_1_alpha.union(path_1_beta)   #eliminate redundat interactors that direcly interact with subunit alpha or beta
	
	subgraph = g.subgraph(final_set)     #generate the subgraph of direct and indirect interaction with subunit alpha and beta
	stats = statistics(subgraph)        #calculate statistics
	degree = stats[0]
	clustering  = stats[1]
	bc = stats[2]
	for x in final_set_path1:     #print degree,clustering coefficient and betweenness centrality per each node direcly interaction with subunit alpha or beta
		print(x,'\t',degree[str(x)],'\t',round(clustering[str(x)],3),'\t',round(bc[str(x)],3))
	
if __name__=='__main__':
	mitabfile = sys.argv[1]
	organism = sys.argv[2]
	pp_int_list = parse_mitab(mitabfile)
	filter_list = filter_organism(pp_int_list,organism)
	unique_ppi = get_unique(filter_list) 
	big_network = network(list(unique_ppi.keys()))
	
	
