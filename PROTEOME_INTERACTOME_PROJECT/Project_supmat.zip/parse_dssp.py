#!/usr/bin/python
import sys
import numpy as np

"""This table contains the estimates of the maximum surface solvent accessible area"""

masa = {'A':115.0, 'L':170.0, 'R':225.0, 'K':200, 'N':160.0, 'M':185.0, 'D':150.0,  \
        'F':210.0, 'C':135.0, 'P':145.0, 'Q':180.0, 'S':115.0, 'E':190.0,  \
        'T':140.0, 'G':75.0, 'W':255.0, 'H':195.0, 'Y':230.0, 'I':175.0, 'V':155.0}

"""The following three functions are additional functions that are not needed for the 
   purpouse of our analysis. The first counts the number of secondary structure per
   secondary structure type. The second create a list containg the psi and phi angles
   per each secondary structure.The third one, otherwise, retrives the solvent accessible
   area for a specific residue (provided as inpunt) from the DSSP file"""
   
# # def count_ss(dssp, ss):
	# # c = 0
	# # for i in dssp.values():
		# # if i[1] == ss:
			# # c += 1
	# # return c

# # def get_ss_angles(dssp, ss):
	# # angles = []
	# # for i in dssp.values():
		# # if i[1] == ss:
			# # angles.append((i[3], i[4]))
	# # return angles

# # def get_asa_residue(dssp, residue):
	# # asa = []
	# # for i in dssp.values():
		# # if i[0] == residue:
			# # asa.append(i[2])
	# # return asa

"""This fucntion has the role of calculating the total solvent accessible area per
    the structure under analysis. The latter is provided as a DSSP file that may contain
    a monomer, a trimer or the entire tetramer. Per each amino acid, it collect the solvent 
    accessible area and sum them up"""
    
def get_total_asa(dssp):
	s = 0.0
	for v in dssp.values():     #iterates over all amino acids in the DSSP file
		s += v[1]
	return s

"""This fucntion calculate the relative solvent accessible area per each amino acid in the DSSP file
   the relative solvent accessible area is calculated as ASA/MASA"""
   
def print_rasa(dssp):
	ks = dssp.keys()
	ks.sort()
	data = []
	for k in ks:
		data += [(k[1], k[0], dssp[k][0],min(1,(dssp[k][1])/(masa[dssp[k][0]])))]  #tuples(chain,numb,AA,rasa)
	return data

"""This fucntion is responsible of calling the function that calculates the relative solvent accessible area
    per each amino acid per each monomer alone in space and together in the tetramer. Then, always per each
    amino acid, it calculates the difference in relative solvent accessible area when the monomer is alone
    in space and when it is inside the complex to quantiy the loss in solvent accessible area. All these results
    are then printed ina user friendly way(table structure)"""
    
def get_diff_rasa(c,m,chain):   #DSSP of the complex, DSSP of the monomer, Chain
	compl = print_rasa(c)      #relative solvent accessible area of amino acids in the complex
	mono = print_rasa(m)       #relative solvent accessible area of the amino acids in the monomer
	mono_in_compl = []
	for y in compl:         #extrac the relative solvent accessible area of a specific chain out from the tetramer
		if y[0]==chain:
			mono_in_compl += [y,]
			
	result_rasa = []
	for i in range(len(mono)):
		if mono[i][3] != mono_in_compl[i][3]:
			perc_rasa = round((mono[i][3]-mono_in_compl[i][3])*100)    #calclate the percentace of loss of relative solvent accessible area
			
			if perc_rasa > 10:               #when the loss is greater them 10%, print it ina table
			     print mono[i][0],'\t',mono[i][2]+str(mono[i][1]),'\t',round(mono[i][3],2),'\t',round(mono_in_compl[i][3],2),'\t',str(perc_rasa)+'%'

	return

"""This function has the role of claculating the surface interaction area of each monomer.
   It has been quantified considering the total solvent accessible area of a monomer(A) inside
   the tetramer and inside a trimer where an other monomer(B) is missing. Then, the difference
   between the total surface accessible area of the monomer(A) when it is inside the trimer and when
   it is inside the tetramer is used to quantify the surface of interraction that this monomer(A)
   has in contact with the monomer (B)that is missing in the trimer"""
   
def get_surf_interraction(complex_prot,trimer,chain):
	chain_dict_complex = {}
	for i in complex_prot:   #retrive the total solvent accessible area of a chain when it is inside the complex
		if i[1] == chain:
			chain_dict_complex[i] = complex_prot[i]
	
	chain_dict_trimer = {}
	for j in trimer:          #retrieve the total solvent accesible area of the chain when it is inside the trimer
		if j[1]==chain:
			chain_dict_trimer[j] = trimer[j]
		
	asa_complex = get_total_asa(chain_dict_complex)    #calculate the ASA in the two cases 
	asa_trimer = get_total_asa(chain_dict_trimer)
	
	return asa_trimer-asa_complex    #compunte the interaction surface between the two monomers

"""This function has the role of parsing the DSSP file and to retrive many information per each amino acids like
   -solvent accesible area
   -chain
   -residue
   -phi and psi angles
   -secondary structure"""
   
def parse_dssp(dsspfile):
	dssp = {}                    #dictionary containing {(res_number,chain):[residue,asa]}
	fdssp = open(dsspfile)      #open the DSSP file provided as input
	c = 0
	for line in fdssp:
		if line.find('  #  RESIDUE') == 0:    #state variable that allows us to collect only information about residues
			c = 1
			continue
		
		if c == 1:
			num = line[5:10].strip()
			ch = line[11]             #number of the residue and the chain as keys
			res = line[13]               #residue type 
			#ss = line[16]                #secondary structure
			asa = float(line[35:38])           #accessible solvent area
			#phi = float(line[103:109])        #angles
			#psi = float(line[109:115])
			#if ss == ' ':
				#ss = 'C'
			try:
				dssp[(int(num), ch)] = [res,asa]   #if it does not find a int number in num (hence it finds a !), it prints an error
			except:
				print >> sys.stderr, 'ERROR:', line  #you print something in standard error, you check whats on the line
				
	return dssp

"""function calls"""

if __name__ == '__main__':
	if len(sys.argv) >= 2:
		complex_prot = sys.argv[1]
		monomer = sys.argv[2]         #comment to get the surface interact
		#trimer = sys.argv[2]         #uncomment to get the surface interaction
		chain = sys.argv[3]
		com = parse_dssp(complex_prot)
		mono = parse_dssp(monomer)
		#tri = parse_dssp(trimer)         #uncomment to get surface interaction
		#print get_surf_interraction(com,tri,str(chain))     #unicomment to get surface interaction
		
		#ss_tot = [count_ss(com, 'H'), count_ss(com, 'E')]   #count the numeber of helix and beta sheet seocndary structures
		#asa_tot = get_total_asa(com)
		
		get_diff_rasa(com,mono,str(chain))      #retrieve relative solvent accessible area table
		
		#print get_ss_angles(com, 'H')       #retrive angles
		#print get_ss_angles(com, 'E')
		#print get_asa_residue(com, 'V')     #retrieve total solvent accessible area for resides V and K
		#print get_asa_residue(com, 'K')   
